package com.yougongzuo.app.core

import android.content.Context
import android.os.SystemClock
import com.yougongzuo.app.data.GuardCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 单次检测管线：
 * 总开关 -> 时间窗 -> 包名与名单单次比对 -> 防自锁过滤 -> 执行拦截 -> 释放。
 */
object GuardRuntime {

    private const val MIN_GAP_MS = 1200L

    @Volatile private var lastPkg: String? = null
    @Volatile private var lastAt: Long = 0L

    /** 返回 true 表示本次已拦截。 */
    suspend fun handle(
        ctx: Context,
        pkg: String?,
        host: BlockerHost? = null,
    ): Boolean {
        if (pkg.isNullOrBlank()) return false
        val cfg = GuardCache.get(ctx)
        if (!cfg.enabled) return false
        if (!TimeWindow.active(TimeWindow.nowMinute(), cfg.startMin, cfg.endMin)) return false
        if (pkg == ctx.packageName) return false
        if (pkg !in cfg.packages) return false
        if (BlockPolicy.isProtected(ctx, pkg)) return false

        val now = SystemClock.elapsedRealtime()
        if (pkg == lastPkg && now - lastAt < MIN_GAP_MS) return true
        lastPkg = pkg
        lastAt = now

        withContext(Dispatchers.IO) {
            Enforcer.enforce(ctx, pkg, cfg.mode, host, RootShell.available())
        }
        return true
    }

    /** 解锁/开屏触发的一次性检测。 */
    suspend fun onUnlock(ctx: Context) {
        val cfg = GuardCache.get(ctx)
        if (!cfg.enabled) return
        if (!TimeWindow.active(TimeWindow.nowMinute(), cfg.startMin, cfg.endMin)) return
        val pkg = ForegroundProbe.current(ctx) ?: return
        handle(ctx, pkg, HostRef.host)
    }
}
