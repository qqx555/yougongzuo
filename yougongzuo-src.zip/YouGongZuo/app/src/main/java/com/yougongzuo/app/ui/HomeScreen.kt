package com.yougongzuo.app.ui

import android.content.Intent
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.yougongzuo.app.core.ForegroundProbe
import com.yougongzuo.app.core.RootShell
import com.yougongzuo.app.core.TimeWindow
import com.yougongzuo.app.data.BlockMode
import com.yougongzuo.app.data.Config
import com.yougongzuo.app.data.GuardConfig
import com.yougongzuo.app.service.GuardAccessibilityService
import com.yougongzuo.app.service.GuardWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val EMERGENCY_PASSWORD = "9527"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    val cfg: GuardConfig? by remember { Config.flow(ctx).map { it as GuardConfig? } }.collectAsStateWithLifecycle(initialValue = null)
    val c = cfg ?: GuardConfig()

    var rootOk by remember { mutableStateOf(false) }
    var accOk by remember { mutableStateOf(false) }
    var usageOk by remember { mutableStateOf(false) }

    var pickerOpen by remember { mutableStateOf(false) }
    var quizOpen by remember { mutableStateOf(false) }
    var confirmOpen by remember { mutableStateOf(false) }
    var emergencyOpen by remember { mutableStateOf(false) }
    var tapCount by remember { mutableStateOf(0) }
    var lastTap by remember { mutableStateOf(0L) }

    var editing by remember { mutableStateOf<EditSlot?>(null) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                accOk = GuardAccessibilityService.isEnabled(ctx)
                usageOk = ForegroundProbe.hasAccess(ctx)
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(Unit) {
        accOk = GuardAccessibilityService.isEnabled(ctx)
        usageOk = ForegroundProbe.hasAccess(ctx)
        rootOk = withContext(Dispatchers.IO) { RootShell.available(true) }
    }

    fun toast(text: String) = Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()

    fun applyEnabled(enabled: Boolean) {
        scope.launch {
            Config.setEnabled(ctx, enabled)
            if (enabled) GuardWorker.schedule(ctx) else GuardWorker.cancel(ctx)
        }
    }

    fun tapTitle() {
        val now = SystemClock.uptimeMillis()
        val fresh = if (now - lastTap < 9000L) tapCount + 1 else 1
        lastTap = now
        tapCount = fresh
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (fresh >= 7) {
            tapCount = 0
            emergencyOpen = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
                title = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { tapTitle() },
                    ) {
                        Text(
                            "有工作",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            "收心 · 自律 · 笃行",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 6.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                StatusCard(
                    c = c,
                    onToggle = { want ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (want) confirmOpen = true else quizOpen = true
                    },
                )
            }
            item {
                WindowCard(
                    c = c,
                    onEdit = { slot -> editing = slot },
                )
            }
            item {
                ModeCard(
                    c = c,
                    rootOk = rootOk,
                    onPick = { m ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        scope.launch { Config.setMode(ctx, m) }
                    },
                )
            }
            item {
                AppsCard(
                    count = c.packages.size,
                    onOpen = { pickerOpen = true },
                )
            }
            item {
                CapabilityCard(
                    rootOk = rootOk,
                    accOk = accOk,
                    usageOk = usageOk,
                    onRootCheck = {
                        scope.launch {
                            rootOk = withContext(Dispatchers.IO) { RootShell.available(true) }
                            toast(if (rootOk) "root 可用" else "未获取到 root，已降级非 root 模式")
                        }
                    },
                    onOpenAccessibility = {
                        runCatching {
                            ctx.startActivity(
                                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    },
                    onOpenUsage = {
                        runCatching {
                            ctx.startActivity(
                                Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    },
                )
            }
            item { EmergencyCard() }
        }
    }

    if (confirmOpen) {
        AlertConfirm(
            title = "开启笃行锁？",
            body = if (c.packages.isEmpty()) {
                "当前限制列表为空，开启后不会拦截任何应用。建议先选择要限制的应用。"
            } else {
                "工作时段 ${TimeWindow.label(c.startMin)} - ${TimeWindow.label(c.endMin)}，共 ${c.packages.size} 个应用受管。开启后关闭需通过三道问答。"
            },
            confirm = "开启",
            onDismiss = { confirmOpen = false },
            onConfirm = {
                confirmOpen = false
                applyEnabled(true)
                toast("笃行锁已开启")
            },
        )
    }

    if (quizOpen) {
        QuizDialog(
            minChars = 12,
            onCancel = {
                quizOpen = false
                toast("已取消关闭，笃行锁继续生效")
            },
            onPass = {
                quizOpen = false
                applyEnabled(false)
                toast("笃行锁已关闭")
            },
        )
    }

    if (emergencyOpen) {
        PasswordDialog(
            hint = "输入紧急密码（默认 9527）",
            onDismiss = { emergencyOpen = false },
            onConfirm = { pwd ->
                if (pwd.trim() == EMERGENCY_PASSWORD) {
                    emergencyOpen = false
                    applyEnabled(false)
                    toast("紧急退出已生效，笃行锁关闭")
                } else {
                    toast("密码不正确")
                }
            },
        )
    }

    if (pickerOpen) {
        AppPickerDialog(
            selected = c.packages,
            onDismiss = { pickerOpen = false },
            onSave = { set ->
                pickerOpen = false
                scope.launch { Config.setPackages(ctx, set) }
                toast("已保存 ${set.size} 个应用")
            },
        )
    }

    val slot = editing
    if (slot != null) {
        TimePickDialog(
            initial = if (slot == EditSlot.START) c.startMin else c.endMin,
            onDismiss = { editing = null },
            onConfirm = { minute ->
                editing = null
                scope.launch {
                    if (slot == EditSlot.START) Config.setWindow(ctx, minute, c.endMin)
                    else Config.setWindow(ctx, c.startMin, minute)
                }
            },
        )
    }
}

enum class EditSlot { START, END }

private fun statusText(c: GuardConfig, inWindow: Boolean): String = when {
    !c.enabled -> "静默待机 · 不做任何限制"
    !TimeWindow.valid(c.startMin, c.endMin) -> "时间配置无效 · 暂不拦截"
    inWindow -> "限制待命中 · 仅比对新启动应用"
    else -> "非工作时段 · 全部放行"
}

@Composable
private fun StatusCard(c: GuardConfig, onToggle: (Boolean) -> Unit) {
    val inWindow = TimeWindow.active(TimeWindow.nowMinute(), c.startMin, c.endMin)
    val active = c.enabled && inWindow
    val accent by animateColorAsState(
        targetValue = if (active) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(280),
        label = "accent",
    )
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Box(
            Modifier.background(
                Brush.linearGradient(
                    listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = if (active) 0.18f else 0.06f),
                        MaterialTheme.colorScheme.surface,
                    )
                )
            )
        ) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = if (c.enabled) Icons.Filled.Lock else Icons.Filled.Shield,
                        contentDescription = null,
                        tint = accent,
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (c.enabled) "笃行锁已开启" else "笃行锁已关闭",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        statusText(c, inWindow),
                        style = MaterialTheme.typography.bodySmall,
                        color = accent,
                    )
                }
                Switch(checked = c.enabled, onCheckedChange = onToggle)
            }
        }
    }
}

@Composable
private fun WindowCard(c: GuardConfig, onEdit: (EditSlot) -> Unit) {
    val valid = TimeWindow.valid(c.startMin, c.endMin)
    SectionCard(
        icon = Icons.Filled.Schedule,
        title = "工作时段",
        trailing = {
            Text(
                if (valid) "24 小时制" else "无效",
                style = MaterialTheme.typography.labelMedium,
                color = if (valid) MaterialTheme.colorScheme.onSurfaceVariant
                else MaterialTheme.colorScheme.error,
            )
        },
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TimeBox(
                label = "开始",
                value = TimeWindow.label(c.startMin),
                modifier = Modifier.weight(1f),
                onClick = { onEdit(EditSlot.START) },
            )
            Text("→", color = MaterialTheme.colorScheme.onSurfaceVariant)
            TimeBox(
                label = "结束",
                value = TimeWindow.label(c.endMin),
                modifier = Modifier.weight(1f),
                onClick = { onEdit(EditSlot.END) },
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            when {
                !valid -> "开始与结束相同，视为无效配置：不进入限制状态。"
                c.startMin > c.endMin -> "跨午夜区间：${TimeWindow.label(c.startMin)} 至次日 ${TimeWindow.label(c.endMin)}。"
                else -> "当日区间：${TimeWindow.label(c.startMin)} - ${TimeWindow.label(c.endMin)}。"
            },
            style = MaterialTheme.typography.bodySmall,
            color = if (valid) MaterialTheme.colorScheme.onSurfaceVariant
            else MaterialTheme.colorScheme.error,
        )
    }
}

@Composable
private fun TimeBox(label: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

@Composable
private fun ModeCard(c: GuardConfig, rootOk: Boolean, onPick: (BlockMode) -> Unit) {
    SectionCard(icon = Icons.Filled.Block, title = "拦截方式") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            BlockMode.entries.forEach { m ->
                FilterChip(
                    selected = c.mode == m,
                    onClick = { onPick(m) },
                    label = { Text(m.title) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            when (c.mode) {
                BlockMode.CRASH -> if (rootOk)
                    "闪退：通过 root 结束目标进程，最彻底；返回桌面作为二次兜底。"
                else
                    "闪退：当前未 root，无法真正结束进程，实际以返回桌面代替。"
                BlockMode.HOME -> if (rootOk)
                    "返回桌面：先回桌面再结束进程，最稳定，默认方案。"
                else
                    "返回桌面：无障碍全局返回主页，无需 root，最稳定。"
                BlockMode.OVERLAY -> "遮罩：以无障碍覆盖层挡住目标界面，点击按钮回桌面；无需悬浮窗权限。"
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun AppsCard(count: Int, onOpen: () -> Unit) {
    SectionCard(
        icon = Icons.Filled.Lock,
        title = "限制应用",
        trailing = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (count == 0) "未选择" else "$count 个",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Icon(
                    Icons.Filled.ChevronRight,
                    null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        onClick = onOpen,
    ) {
        Text(
            if (count == 0) "尚未选择应用，开启后不会拦截任何内容。"
            else "仅在工作时段内、这些应用被新启动时拦截一次。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "桌面、系统界面、设置、电话、短信、输入法等已被强制保护，不可选。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
        )
    }
}

@Composable
private fun CapabilityCard(
    rootOk: Boolean,
    accOk: Boolean,
    usageOk: Boolean,
    onRootCheck: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onOpenUsage: () -> Unit,
) {
    SectionCard(icon = Icons.Filled.Shield, title = "运行模式与权限") {
        CapRow("root", if (rootOk) "已就绪" else "未检测到（降级）", rootOk)
        Spacer(Modifier.height(8.dp))
        CapRow("无障碍服务", if (accOk) "已开启 · 事件驱动" else "未开启 · 无法拦截", accOk)
        Spacer(Modifier.height(8.dp))
        CapRow("使用情况访问", if (usageOk) "已授权 · 解锁单次检测" else "未授权 · 仅 App 启动检测", usageOk)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onOpenAccessibility, modifier = Modifier.weight(1f)) {
                Text("无障碍", style = MaterialTheme.typography.labelLarge)
            }
            OutlinedButton(onClick = onOpenUsage, modifier = Modifier.weight(1f)) {
                Text("使用情况", style = MaterialTheme.typography.labelLarge)
            }
            OutlinedButton(onClick = onRootCheck, modifier = Modifier.weight(1f)) {
                Text("重测 root", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
private fun CapRow(name: String, value: String, ok: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(
                    if (ok) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                )
        )
        Spacer(Modifier.width(10.dp))
        Text(name, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(
            value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun EmergencyCard() {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        ),
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(
                "紧急退出",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "连续点击顶部标题 7 次，输入紧急密码即可关闭笃行锁（默认 9527）。此路径不受三道问答约束，用于防止设备被自己锁死。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = { }) {
                Text(
                    "检测仅由解锁与新应用启动事件触发，不轮询进程",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

@Composable
private fun SectionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    trailing: (@Composable () -> Unit)? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier,
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    icon,
                    null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                trailing?.invoke()
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}
