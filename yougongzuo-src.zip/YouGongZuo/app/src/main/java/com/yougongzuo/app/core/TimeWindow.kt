package com.yougongzuo.app.core

/** 以「当天分钟数 0..1439」表示时间窗口。 */
object TimeWindow {

    fun valid(start: Int, end: Int): Boolean = start in 0..1439 && end in 0..1439 && start != end

    /** start > end 视为跨午夜；start == end 视为无效。 */
    fun active(nowMinute: Int, start: Int, end: Int): Boolean = when {
        !valid(start, end) -> false
        start < end -> nowMinute in start until end
        else -> nowMinute >= start || nowMinute < end
    }

    fun label(minute: Int): String {
        val m = ((minute % 1440) + 1440) % 1440
        return "%02d:%02d".format(m / 60, m % 60)
    }

    fun parse(text: String): Int? {
        val parts = text.trim().split(":", "：")
        if (parts.size != 2) return null
        val h = parts[0].trim().toIntOrNull() ?: return null
        val m = parts[1].trim().toIntOrNull() ?: return null
        if (h !in 0..23 || m !in 0..59) return null
        return h * 60 + m
    }

    fun nowMinute(): Int {
        val c = java.util.Calendar.getInstance()
        return c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
    }
}
