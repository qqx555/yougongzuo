package com.yougongzuo.app

import android.app.Application
import com.yougongzuo.app.core.GuardCache
import com.yougongzuo.app.core.GuardRuntime
import com.yougongzuo.app.data.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class App : Application() {

    override fun onCreate() {
        super.onCreate()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope.launch {
            runCatching {
                Config.flow(this@App).collect { GuardCache.config = it }
            }
        }
        // App 启动时的一次性检测（与解锁检测同一管线，不驻留）
        scope.launch { runCatching { GuardRuntime.onUnlock(this@App) } }
    }
}
