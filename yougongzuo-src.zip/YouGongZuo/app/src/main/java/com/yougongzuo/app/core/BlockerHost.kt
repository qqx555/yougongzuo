package com.yougongzuo.app.core

/** 由无障碍服务实现；遮罩使用 TYPE_ACCESSIBILITY_OVERLAY，无需悬浮窗权限。 */
interface BlockerHost {
    fun showOverlay(pkg: String): Boolean
    fun goHome()
}

/** 无障碍服务连接时注册，断开即清空；事件外（如解锁广播）复用。 */
object HostRef {
    @Volatile
    var host: BlockerHost? = null
}
