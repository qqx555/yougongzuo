package com.yougongzuo.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.store: DataStore<Preferences> by preferencesDataStore(name = "guard_config")

enum class BlockMode(val title: String) {
    CRASH("闪退"),
    HOME("返回桌面"),
    OVERLAY("遮罩");

    companion object {
        fun of(v: String?): BlockMode = entries.firstOrNull { it.name == v } ?: HOME
    }
}

data class GuardConfig(
    val enabled: Boolean = false,
    val startMin: Int = 9 * 60,
    val endMin: Int = 18 * 60,
    val packages: Set<String> = emptySet(),
    val mode: BlockMode = BlockMode.HOME,
)

object Config {
    private val K_ENABLED = booleanPreferencesKey("enabled")
    private val K_START = intPreferencesKey("start")
    private val K_END = intPreferencesKey("end")
    private val K_PKGS = stringSetPreferencesKey("pkgs")
    private val K_MODE = stringPreferencesKey("mode")

    fun flow(ctx: Context): Flow<GuardConfig> = ctx.store.data.map { p ->
        GuardConfig(
            enabled = p[K_ENABLED] ?: false,
            startMin = p[K_START] ?: 540,
            endMin = p[K_END] ?: 1080,
            packages = p[K_PKGS] ?: emptySet(),
            mode = BlockMode.of(p[K_MODE]),
        )
    }

    suspend fun load(ctx: Context): GuardConfig = flow(ctx).first()

    suspend fun setEnabled(ctx: Context, value: Boolean) =
        ctx.store.edit { it[K_ENABLED] = value }

    suspend fun setWindow(ctx: Context, start: Int, end: Int) =
        ctx.store.edit { it[K_START] = start; it[K_END] = end }

    suspend fun setMode(ctx: Context, mode: BlockMode) =
        ctx.store.edit { it[K_MODE] = mode.name }

    suspend fun setPackages(ctx: Context, pkgs: Set<String>) =
        ctx.store.edit { it[K_PKGS] = pkgs }
}
