package com.yougongzuo.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF6EE7A8),
    onPrimary = Color(0xFF06231A),
    primaryContainer = Color(0xFF1E3A30),
    onPrimaryContainer = Color(0xFFB9F5D3),
    secondary = Color(0xFF9DB3A8),
    background = Color(0xFF0E1114),
    onBackground = Color(0xFFE8F5EE),
    surface = Color(0xFF161B20),
    onSurface = Color(0xFFE8F5EE),
    surfaceVariant = Color(0xFF1E262C),
    onSurfaceVariant = Color(0xFF9DB3A8),
    outline = Color(0xFF2F3A40),
    error = Color(0xFFFF8A80),
)

private val Light = lightColorScheme(
    primary = Color(0xFF1F7A4D),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFC8F2DB),
    onPrimaryContainer = Color(0xFF05291B),
    secondary = Color(0xFF4A5A52),
    background = Color(0xFFF6FAF7),
    onBackground = Color(0xFF10201A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF10201A),
    surfaceVariant = Color(0xFFE6F1EA),
    onSurfaceVariant = Color(0xFF4A5A52),
    outline = Color(0xFFC3D3CA),
    error = Color(0xFFB3261E),
)

@Composable
fun YGTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
