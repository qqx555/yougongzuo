package com.yougongzuo.app.data

import android.content.Context

/** 进程内配置缓存：事件触发时避免反复读盘。 */
object GuardCache {
    @Volatile
    var config: GuardConfig? = null

    suspend fun get(ctx: Context): GuardConfig =
        config ?: Config.load(ctx).also { config = it }
}
