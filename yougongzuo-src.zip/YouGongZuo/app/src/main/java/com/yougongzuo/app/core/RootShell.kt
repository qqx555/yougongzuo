package com.yougongzuo.app.core

import java.util.concurrent.TimeUnit

/** 最小 root 调用：单次 su -c，带超时与退出码，不常驻 shell，不接受未校验包名。 */
object RootShell {

    private val PKG = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)*$")

    @Volatile
    private var cached: Boolean? = null

    private data class Result(val code: Int, val out: String)

    fun available(refresh: Boolean = false): Boolean {
        if (!refresh) cached?.let { return it }
        val r = exec(listOf("su", "-c", "id"), 4000)
        val ok = r.code == 0 && r.out.contains("uid=0")
        cached = ok
        return ok
    }

    fun forceStop(pkg: String): Boolean {
        if (!PKG.matches(pkg)) return false
        val r = exec(listOf("su", "-c", "am force-stop --user current $pkg"), 5000)
        return r.code == 0
    }

    private fun exec(cmd: List<String>, timeoutMs: Long): Result {
        var proc: Process? = null
        val sb = StringBuilder()
        return try {
            val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
            proc = p
            val reader = Thread {
                runCatching {
                    p.inputStream.bufferedReader().useLines { lines ->
                        lines.forEach { sb.append(it).append('\n') }
                    }
                }
            }.apply { isDaemon = true; start() }
            val finished = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!finished) {
                p.destroyForcibly()
                Result(-1, "timeout")
            } else {
                reader.join(400)
                Result(p.exitValue(), sb.toString())
            }
        } catch (t: Throwable) {
            Result(-2, t.message ?: "error")
        } finally {
            runCatching { proc?.destroy() }
        }
    }
}
