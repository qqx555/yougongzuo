package com.yougongzuo.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.yougongzuo.app.core.GuardCache
import com.yougongzuo.app.core.GuardRuntime
import com.yougongzuo.app.data.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** 重启/升级后从 DataStore 恢复配置，并按需登记兜底任务。 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        if (intent?.action == null) return
        val app = ctx.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                GuardCache.config = Config.load(app)
                if (GuardCache.config?.enabled == true) GuardWorker.schedule(app)
                else GuardWorker.cancel(app)
            } catch (_: Throwable) {
            } finally {
                pending.finish()
            }
        }
    }
}

/** 解锁时单次检测（ACTION_USER_PRESENT）。 */
class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_USER_PRESENT) return
        val app = ctx.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                GuardRuntime.onUnlock(app)
            } catch (_: Throwable) {
            } finally {
                pending.finish()
            }
        }
    }
}
