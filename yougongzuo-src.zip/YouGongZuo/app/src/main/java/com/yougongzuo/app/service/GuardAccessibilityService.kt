package com.yougongzuo.app.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import com.yougongzuo.app.R
import com.yougongzuo.app.core.BlockPolicy
import com.yougongzuo.app.core.BlockerHost
import com.yougongzuo.app.core.GuardCache
import com.yougongzuo.app.core.GuardRuntime
import com.yougongzuo.app.core.HostRef
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class GuardAccessibilityService : AccessibilityService(), BlockerHost {

    companion object {
        @Volatile
        var instance: GuardAccessibilityService? = null
            private set

        fun isEnabled(ctx: Context): Boolean = runCatching {
            val flat = ComponentName(ctx, GuardAccessibilityService::class.java).flattenToString()
            val raw = Settings.Secure.getString(
                ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            raw.split(':').any { it.equals(flat, ignoreCase = true) }
        }.getOrDefault(false)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var overlayWm: WindowManager? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        HostRef.host = this
        scope.launch { GuardCache.get(this@GuardAccessibilityService) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        // 系统基础程序：如已放行系统界面，收起残留遮罩
        if (BlockPolicy.isProtected(this, pkg)) {
            hideOverlay()
            return
        }
        scope.launch { GuardRuntime.handle(this@GuardAccessibilityService, pkg, this@GuardAccessibilityService) }
    }

    override fun showOverlay(pkg: String): Boolean {
        if (overlay != null) return true
        return runCatching {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            )
            val view = LayoutInflater.from(this).inflate(R.layout.overlay_block, null)
            view.findViewById<TextView>(R.id.block_desc)?.text = "「$pkg」不在本轮工作时段允许范围内。"
            view.findViewById<TextView>(R.id.block_action)?.setOnClickListener {
                hideOverlay()
                goHome()
            }
            wm.addView(view, lp)
            overlay = view
            overlayWm = wm
            main.postDelayed({ hideOverlay() }, 8000L)
            true
        }.getOrDefault(false)
    }

    override fun goHome() {
        runCatching { performGlobalAction(GLOBAL_ACTION_HOME) }
        hideOverlay()
    }

    fun hideOverlay() {
        main.post {
            val v = overlay ?: return@post
            overlay = null
            runCatching { overlayWm?.removeView(v) }
            overlayWm = null
        }
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        instance = null
        if (HostRef.host === this) HostRef.host = null
        hideOverlay()
        runCatching { scope.cancel() }
    }
}
