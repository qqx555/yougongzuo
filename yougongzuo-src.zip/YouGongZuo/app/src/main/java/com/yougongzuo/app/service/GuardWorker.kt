package com.yougongzuo.app.service

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.yougongzuo.app.core.ForegroundProbe
import com.yougongzuo.app.core.GuardCache
import com.yougongzuo.app.core.GuardRuntime
import com.yougongzuo.app.core.HostRef
import com.yougongzuo.app.core.TimeWindow
import java.util.concurrent.TimeUnit

/** 极少数兜底：30 分钟一次，仅在总开关开启时由系统调度。 */
class GuardWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext
        val cfg = GuardCache.get(app)
        if (!cfg.enabled) return Result.success()
        if (!TimeWindow.active(TimeWindow.nowMinute(), cfg.startMin, cfg.endMin)) return Result.success()
        val pkg = ForegroundProbe.current(app) ?: return Result.success()
        GuardRuntime.handle(app, pkg, HostRef.host)
        return Result.success()
    }

    companion object {
        private const val NAME = "guard_beat"

        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<GuardWorker>(30, TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder().setRequiresBatteryNotLow(true).build()
                )
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun cancel(ctx: Context) {
            WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
        }
    }
}
