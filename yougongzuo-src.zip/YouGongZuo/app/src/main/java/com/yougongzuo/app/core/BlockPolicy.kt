package com.yougongzuo.app.core

import android.content.Context
import android.content.Intent
import android.provider.Settings

/** 设备可用性保护：这些包永不可拦截。 */
object BlockPolicy {

    private val STATIC: Set<String> = setOf(
        "com.android.systemui",
        "com.android.settings",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.dialer",
        "com.google.android.dialer",
        "com.android.incallui",
        "com.android.emergency",
        "com.android.mms",
        "com.android.messaging",
        "com.google.android.apps.messaging",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.inputmethod.latin",
        "com.google.android.inputmethod.latin",
        "com.android.providers.settings",
        "com.android.shell",
        "com.android.bluetooth",
        "com.android.nfc",
        "com.android.keychain",
        "com.android.certinstaller",
        "com.android.documentsui",
        "com.android.vending",
    )

    @Volatile
    private var launcherCache: Set<String>? = null

    private fun launchers(ctx: Context): Set<String> = launcherCache ?: run {
        val set = runCatching {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.queryIntentActivities(intent, 0)
                .mapNotNull { it.activityInfo?.packageName }
                .toSet()
        }.getOrDefault(emptySet())
        launcherCache = set
        set
    }

    fun isProtected(ctx: Context, pkg: String): Boolean {
        if (pkg.isBlank()) return true
        if (pkg == ctx.packageName) return true
        if (pkg in STATIC) return true
        if (pkg in launchers(ctx)) return true
        if (pkg.contains("launcher", ignoreCase = true) || pkg.contains("home", ignoreCase = true)) return true
        if (pkg.contains("inputmethod", ignoreCase = true) || pkg.contains("keyboard", ignoreCase = true)) return true
        val ime = runCatching {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        }.getOrNull()?.substringBefore('/')
        if (!ime.isNullOrBlank() && pkg == ime) return true
        return false
    }

    /** 返回不可选原因，null 表示可选。 */
    fun reason(ctx: Context, pkg: String): String? = when {
        pkg == ctx.packageName -> "本应用自身"
        pkg in STATIC || pkg in launchers(ctx) -> "系统基础程序"
        pkg.contains("launcher", true) -> "桌面"
        pkg.contains("inputmethod", true) -> "输入法"
        else -> null
    }
}
