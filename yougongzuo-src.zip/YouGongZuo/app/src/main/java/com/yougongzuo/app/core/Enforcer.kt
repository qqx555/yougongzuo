package com.yougongzuo.app.core

import android.content.Context
import com.yougongzuo.app.data.BlockMode

object Enforcer {

    /** 返回实际执行的策略名：crash / home / home-fallback / overlay。 */
    fun enforce(
        ctx: Context,
        pkg: String,
        mode: BlockMode,
        host: BlockerHost?,
        root: Boolean,
    ): String = when (mode) {
        BlockMode.CRASH -> {
            if (root && RootShell.forceStop(pkg)) "crash"
            else { host?.goHome(); "home-fallback" }
        }
        BlockMode.HOME -> {
            host?.goHome()
            if (root) RootShell.forceStop(pkg)
            "home"
        }
        BlockMode.OVERLAY -> {
            val shown = host?.showOverlay(pkg) ?: false
            if (!shown) host?.goHome()
            "overlay"
        }
    }
}
