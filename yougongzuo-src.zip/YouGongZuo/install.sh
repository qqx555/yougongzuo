#!/usr/bin/env bash
# 一次装好并打开必要权限（release 需自行签名）
set -euo pipefail
PKG=com.yougongzuo.app
APK=${1:-app/build/outputs/apk/debug/app-debug.apk}
adb install -r "$APK"
adb shell appops set "$PKG" GET_USAGE_STATS allow || true
adb shell settings put secure enabled_accessibility_services "$PKG/$PKG.service.GuardAccessibilityService" || true
adb shell settings put secure accessibility_enabled 1 || true
adb shell am start -n "$PKG/.MainActivity"
