#!/usr/bin/env bash
# 回滚：关闭无障碍 → 撤销使用情况授权 → 卸载
set -euo pipefail
PKG=com.yougongzuo.app
adb shell settings put secure enabled_accessibility_services "" || true
adb shell settings put secure accessibility_enabled 0 || true
adb shell appops set "$PKG" GET_USAGE_STATS default || true
adb uninstall "$PKG" || true
