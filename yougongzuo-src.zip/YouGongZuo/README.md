# 有工作 · 笃行锁

收心/自律工具。Android 8.0+（minSdk 26），编译与目标 SDK 34，Material3 + Compose。

## 一、工作原理（事件驱动，单次比对）

```
解锁(ACTION_USER_PRESENT) ─┐
新应用启动(TYPE_WINDOW_STATE_CHANGED) ─┤
App 冷启动 ─┘
        ↓
总开关? ──关──> 静默待机
   │开
时间窗(支持跨午夜，start==end 无效) ──不在──> 放行/待机
   │在
包名 × 限制名单（单次比对）
   │命中且非保护包
拦截：闪退 / 返回桌面 / 遮罩 → 立即释放协程与窗口
```

- 不轮询进程、不常驻 root shell、无常驻前台服务；每个事件一个短协程，结束即释放。
- 遮罩用 `TYPE_ACCESSIBILITY_OVERLAY`，不需要悬浮窗权限。
- DataStore 持久化总开关/时间窗/名单/拦截方式；开机 `BOOT_COMPLETED` 恢复；时区变更按系统当前时间重算。
- WorkManager 30 分钟兜底（仅在开启时登记），非主路径。

## 二、防自锁

强制保护（列表内不可选、运行时二次校验）：本应用、所有桌面（`CATEGORY_HOME`）、SystemUI、设置、电话/通话中、紧急呼叫、短信、输入法（静态 + 系统默认 IME）、权限管理、包安装器、蓝牙/NFC/证书安装、DocumentsUI。

紧急退出：连点顶部标题 7 次 → 输入紧急密码（默认 `9527`）→ 立即关闭笃行锁。该通道不受三道问答约束。

## 三、三道问答

关闭总开关时依次提问：①你真的要放弃这次宝贵的时机吗？②我们得做点有用的事吧？③不要放弃啊？
每题非空且 ≥12 字才可提交；`DialogProperties(dismissOnBackPress=false, dismissOnClickOutside=false)`，返回/点外部/点「放弃并保留锁定」= 取消关闭，锁定维持。三题全过才写 `enabled=false`。再次开启需确认弹窗。

## 四、能力差异（诚实说明）

| 方式 | root 模式 | 非 root 模式 |
|---|---|---|
| 闪退 | `su -c am force-stop` 真正结束进程 | 无法做到，自动降级为返回桌面 |
| 返回桌面（默认） | 先 `GLOBAL_ACTION_HOME` 再 force-stop | `GLOBAL_ACTION_HOME` |
| 遮罩 | 无障碍覆盖层 | 无障碍覆盖层 |

root 调用：单次 `su -c`，`ProcessBuilder` 传参、包名正则校验（`^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)*$`）、显式超时（5s）、退出码判定、不拼接用户输入。

## 五、构建 / 安装 / 回滚

```bash
# 本机（需 JDK17 + Android SDK platform34/build-tools34 + Gradle 8.7）
./build.sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
# 或一键装并授权
./install.sh

# 回滚
./uninstall.sh
```

手动开权限：设置 → 无障碍 → 「有工作 · 笃行锁」；设置 → 特殊权限 → 使用情况访问 → 有工作。

## 六、验收标准

1. 冷启动/切后台回来：不崩溃，配置正确回显（DataStore）。
2. 总开关关：任意应用可用，无任何拦截。
3. 工作时段内打开名单内应用 → 按所选方式拦截一次；名单外/受保护包 → 放行。
4. `22:00-06:00` 在 23:30 与 05:30 均命中，在 12:00 不命中。
5. 开始=结束：界面提示无效，不进入拦截。
6. 关闭总开关：三题任一空/不足 12 字/中途返回 → 保持开启；三题全过 → 关闭。
7. 连点标题 7 次 + 密码 → 立即关闭。
8. 开启限制后：可回桌面、可拨号、可进设置（受保护包永不拦截）。
9. 列表中的启动器/设置/电话/输入法呈灰色「系统保护 · 不可选」。
10. 无 root 时：`root` 状态显示「未检测到（降级）」，闪退选择时文案说明实际走返回桌面，功能不崩溃。

## 七、低功耗

事件驱动（仅 `TYPE_WINDOW_STATE_CHANGED` + `USER_PRESENT`）；`notificationTimeout=120ms`；配置走内存缓存 + DataStore；无网络、无定位、无轮询定时器；遮罩 8s 自动回收；动画仅 280ms 颜色过渡；WorkManager 兜底 30 分钟且要求电量不低。

## 八、需要补充的图片（最多 3 项，均为可选增强）

1. `res/drawable/hero_state.webp`：首页顶部状态插画（建议 1080×540，深/浅两版）。
2. `res/drawable/ic_lock_badge.png`：遮罩页徽标（96×96，透明底，可选替换 `bg_lock_badge.xml`）。
3. `res/mipmap-xxxhdpi/ic_launcher.png`：品牌启动图标（432×432，替换自适应图标前景）。

未提供时全部使用代码绘制的矢量/形状占位，不影响运行。

## 九、GitHub Actions 构建（手机可完成）

仓库根放 `yougongzuo-src.zip` 与 `.github/workflows/build.yml` 即可：
workflow 会解压源码、定位 `settings.gradle.kts`、装 JDK17 + SDK + Gradle 8.7、构建 debug APK 并上传 artifact。
详见上级目录 `手机推送到GitHub.md`。
