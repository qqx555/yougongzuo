#!/usr/bin/env bash
# 需要：JDK 17+、Gradle 8.7+、Android SDK(platform 34 / build-tools 34.0.0)
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_SDK_ROOT:=$HOME/Android/Sdk}"
export ANDROID_SDK_ROOT
echo "sdk.dir=$ANDROID_SDK_ROOT" > local.properties
gradle --no-daemon :app:assembleDebug -x lint
APK=app/build/outputs/apk/debug/app-debug.apk
ls -l "$APK"
echo "安装：adb install -r $APK"
